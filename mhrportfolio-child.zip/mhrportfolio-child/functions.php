<?php
	add_action( 'wp_enqueue_scripts', 'mhrportfolio_child_enqueue_styles' );
	function mhrportfolio_child_enqueue_styles() {
	 
	    $parent_style = 'parent-style';
	 
	    wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css', array( 'google-fonts', 'mhrportfolio-fonts', 'bootstrap-css', 'normalize-css' ) );
	    wp_enqueue_style( 'child-style',
	        get_stylesheet_directory_uri() . '/style.css',
	        array( $parent_style ),
	        wp_get_theme()->get('Version')
	    );
    }
 